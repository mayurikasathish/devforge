const express = require('express');
const router = express.Router();
const axios = require('axios');

const PISTON_API_URL = process.env.PISTON_API_URL || 'http://localhost:2000';

// @route   POST /api/code/execute
// @desc    Execute code using Piston
// @access  Public
router.post('/execute', async (req, res) => {
  try {
    const { language, code, stdin } = req.body;

    if (!language || !code) {
      return res.status(400).json({
        success: false,
        error: 'Language and code are required'
      });
    }

    const response = await axios.post(`${PISTON_API_URL}/api/v2/execute`, {
      language,
      version: '*',
      files: [{ content: code }],
      stdin: stdin || ''
    }, {
      timeout: 10000
    });

    res.json({
      success: true,
      output: response.data.run?.stdout || '',
      error: response.data.run?.stderr || '',
      exitCode: response.data.run?.code
    });

  } catch (error) {
    console.error('Code execution error:', error.message);
    res.status(500).json({
      success: false,
      error: error.response?.data?.message || 'Code execution failed'
    });
  }
});

// @route   GET /api/code/languages
// @desc    Get available languages
// @access  Public
router.get('/languages', async (req, res) => {
  try {
    const response = await axios.get(`${PISTON_API_URL}/api/v2/runtimes`, {
      timeout: 5000
    });
    res.json({
      success: true,
      languages: response.data
    });
  } catch (error) {
    console.error('Failed to fetch languages:', error.message);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch available languages'
    });
  }
});

module.exports = router;
